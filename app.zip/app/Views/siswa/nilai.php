<?= $this->extend('template/template-biodata') ?>
<?= $this->section('content') ?>

<div class="card">
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Tahun Pelajaran</th>
                    <th>Semester Genap</th>
                    <th>Lihat Hasil</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td scope=""></td>
                    <td></td>
                    <td></td>
                </tr>

            </tbody>
        </table>
    </div>
</div>



<?= $this->endSection() ?>